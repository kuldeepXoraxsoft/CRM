import client from "./client";

export const authApi = {
  login: (email, password) =>
    client.post("/auth/login", { email, password }).then((r) => r.data),

  me: () =>
    client.get("/auth/me").then((r) => r.data),

  changePassword: (currentPassword, newPassword) =>
    client
      .patch("/auth/password", {
        currentPassword,
        newPassword,
      })
      .then((r) => r.data),
};